
____Welcome____


<a href="https://github.com/Sarfraz-Ssb/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Sarfraz-Ssb?label=Followers&color=green&style=flat-square"></a>

<br>
  <a href="https://github.com/Sarfraz-Ssb/termux-style/stargazers/">
  <a href="https://github.com/Sarfraz-Ssb/SSB">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Sarfraz-Ssb/SSB.svg"/>
  </a>
<br>
  <a href="https://github.com/Sarfraz-Ssb/SSB">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Sarfraz-Ssb/SSB.svg"/>
  </a>
  <a href="https://github.com/Sarfraz-Ssb/SSB">
    <img alt="Starts" src="https://img.shields.io/github/stars/Sarfraz-Ssb/SSB.svg"/>
  </a>
<br>
<a href="https://github.com/Sarfraz-Ssb/SSB">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Sarfraz-Ssb/SSB.svg"/>
  </a>
<br>
<a href="https://github.com/Sarfraz-Ssb/SSB">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Sarfraz-Ssb/SSB.svg"/> <a                                                                                                        href="https://github.com/Azim-vau/fcpromax">
    <img alt="Forks" src="https://img.shields.io/github/forks/Sarfraz-Ssb/SSB.svg"/>
  </a>
</div>

</br>
<p align="center">
      FACEBOOK ACCOUNT CLONER
</p>
  
#### INSTALL TOOL ON TERMUX
```python
 pkg update
 pkg upgrade
 pkg install python
 pkg install git
 pip install requests
 pip install bs4
 pip install futures
 pip install mechanize
 cd $HOME 
 rm -rf SSB
 git clone https://github.com/Sarfraz-Ssb/SSB
```
#### RUN SCRIPT
```python
 cd SSB
 python SSB.py
```


#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=red&labelColor=black)](https://github.com/Sarfraz-Ssb) <br>
[![](https://img.shields.io/badge/Facebook-black?logo=Facebook&logoColor=red&labelColor=blue)](https://www.facebook.com/sarfraz.baloch.07) <br>
[![](https://img.shields.io/badge/Facebook-black?logo=Facebook&logoColor=yellow&labelColor=red)](https://facebook.com/groups/3017062245271082/) <br>

<h2> THANKS FOR VISIT <h2\>

